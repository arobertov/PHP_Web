<?php
/**
 * Created by PhpStorm.
 * User: Angel
 * Date: 30.9.2017 г.
 * Time: 17:57
 */
class Car {
	public $brand;
	public $model;
	public $year;
}

$car1= new Car();

$car2 = new Car();

$car3 = new Car();