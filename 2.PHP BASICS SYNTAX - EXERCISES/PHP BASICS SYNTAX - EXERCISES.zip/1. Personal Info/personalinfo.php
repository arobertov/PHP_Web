<?php
/**
 * Created by PhpStorm.
 * User: Angel
 * Date: 22.9.2017 г.
 * Time: 0:18
 */

$firstName = fgets(STDIN);
$lastName = fgets(STDIN);
$age = fgets(STDIN);

echo "My name is $firstName $lastName and I am $age years old.";
