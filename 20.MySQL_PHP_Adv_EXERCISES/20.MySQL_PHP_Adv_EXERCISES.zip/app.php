Audi, A4, 2004, Ivan, Ivanov, BGN 7000 Audi, A4, 2004, Ivan, Ivanov, BGN 7000 <?php
include "db_config.php";
include "Carshop.php";
$shop = new Carshop($db);
$shop->main();