<?php
/**
 * Created by PhpStorm.
 * User: Angel
 * Date: 6.10.2017 г.
 * Time: 14:38
 */
include ('Vehicle.php');

$car = new Vehicle('5+1','Red','Opel','Astra','2007');
