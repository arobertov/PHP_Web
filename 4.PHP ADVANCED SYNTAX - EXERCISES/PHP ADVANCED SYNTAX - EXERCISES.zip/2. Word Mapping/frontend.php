<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
	      content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<style>
		table, th, td {
			border: 1px solid black;
			margin: 10px;
		}
		td {
			padding: 10px;
		}
	</style>
	<title>Document</title>
</head>
<body>
<!------------ submit form start ----------------------->
	<form method="get">
		<div>
			<textarea name="input" rows="3" cols="70"></textarea>
		</div>
		<div>
			<input type="submit" name="submit" value="Count Words">
		</div>
	</form>
<!------------ submit form end ------------------------>

