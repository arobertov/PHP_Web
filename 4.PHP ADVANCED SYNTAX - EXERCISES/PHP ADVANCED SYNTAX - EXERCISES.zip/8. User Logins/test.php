<?php
/**
 * Created by PhpStorm.
 * User: Angel
 * Date: 26.9.2017 г.
 * Time: 10:56
 */
while (1){
	$input = trim(fgets(STDIN));

	 $arr['Gotin']['pos'] = $input;
	 print_r($arr);
	 exit;
}